<?php return array('dependencies' => array(), 'version' => '09b9c1b1d2cce80f6966');
