 <main
     class="twg-flex-1 twg-flex twg-flex-col  lg:twg-max-h-[calc(100vh-90px)] max-lg:twg-max-h-[calc(100vh-69px)] "> 
     <section class="twg-flex-1 twg-pt-5 twg-flex twg-h-full max-lg:twg-flex-col max-lg:twg-overflow-y-auto max-lg:twg-px-4 max-lg:twg-space-y-6 max-lg:twg-pb-5 twg-relative twg-main-content-section">
     <?php echo student_menu($settings['dashboard_page']); ?>

         <div
             class="twg-main-wrapper-content lg:twg-flex-1 lg:twg-overflow-y-auto lg:twg-px-5 max-lg:!twg-mt-0">
             <div class="twg-custom-calendar twg-pb-5 twg-rounded-lg twg-border twg-border-[#ddd]">
                 <div id="calendar"></div>
             </div>
         </div>
     </section>

 </main>
 <div
     class="twg-fixed twg-inset-0 twg-size-full twg-z-20 twg-backdrop-blur-[4px] twg-overlay twg-hidden"></div>
 