<?php 


/* Documantation
 * Message psot type - Init Hook - activation.php
 * Send Message Function - send_message_student() -  Ajax.php
 * Get messages in dashbaoard - functions.php
 * Student Profile